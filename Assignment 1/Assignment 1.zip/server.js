var PORT = 41101;
var http = require('http');
var url = require('url');
var querystring = require('querystring');
var fs = require('fs');
var file = __dirname + '/favs.json';
var info;
var param;

//Creating Root class
//This class will act like the root of a tree, pointing
//to the next directories. It will also be able to treat
//requests for "/"
function Root(pathString){
    this.subdirectories = new Array();
    this.pathString = pathString;
    this.level = 0;
}

Root.prototype.setSubDirectories = function(){
    this.subdirectories["tweets"] = new TweetsDirectory(this.pathString);
    this.subdirectories["users"] = new UsersDirectory(this.pathString);
    this.subdirectories["links"] = new LinksDirectory(this.pathString);
    this.subdirectories["tweet"] = new TweetDirectory(this.pathString);
    this.subdirectories["user"] = new UserDirectory(this.pathString);
    this.subdirectories["mostpopulars"] = new MostPopularsDirectory(this.pathString);
}

Root.prototype.treat = function(response, param){
    response.writeHead(200, {'Content-Type': 'text/html'});
    fs.readFile(__dirname + '/index.html', function(err, data) {
        response.write(data);
        response.end();
    });
}

Root.prototype.respondToRequest = function(response, param){
	this.setSubDirectories();
    if(!this.pathString[this.level + 1] || this.pathString[this.level + 1] == ""){
        this.treat(response, param);
    }
    else if(this.subdirectories[this.pathString[this.level + 1]]){
        this.subdirectories[this.pathString[this.level + 1]].respondToRequest(response);
    } else{
        ret = {};
        response.end(JSON.stringify(ret));
    } 
}

//Creating TweetsDirectory class.
//This class will treat requests for "/tweets"
//Inherits from Root
function TweetsDirectory(pathString){
    Root.call(this, pathString);
    this.level = 1;
}

TweetsDirectory.prototype.setSubDirectories = function(){}
TweetsDirectory.prototype = new Root();
TweetsDirectory.prototype.constructor = TweetsDirectory;

TweetsDirectory.prototype.treat = function(response){
	ret = [];
	i = 0;
    while(info[i]) {
        ret.push({"id" : info[i].id, "tweet" : info[i].text});
        i ++;
    }
    response.end(JSON.stringify(ret));
}

TweetsDirectory.prototype.respondToRequest = function(response){
    Root.prototype.respondToRequest.call(this, response);
}


//Creating UsersDirectory class.
//This class will treat requests for "/users"
//Inherits from Root
function UsersDirectory(pathString){
    Root.call(this, pathString);
    this.level = 1;
}

UsersDirectory.prototype.setSubDirectories = function(){}
UsersDirectory.prototype = new Root();
UsersDirectory.prototype.constructor = UsersDirectory;

UsersDirectory.prototype.treat = function(response){
	ret = [];
	i = 0;
    while(info[i]) {
        ret.push({"id" : info[i].user.id, "user" : info[i].user.name});
        i ++;
    }
    response.end(JSON.stringify(ret));
}

UsersDirectory.prototype.respondToRequest = function(response){
    Root.prototype.respondToRequest.call(this, response);
}


//Creating LinksDirectory class.
//This class will treat requests for "/links"
//Inherits from Root
function LinksDirectory(pathString){
    Root.call(this, pathString);
    this.level = 1;
}

LinksDirectory.prototype.setSubDirectories = function(){}
LinksDirectory.prototype = new Root();
LinksDirectory.prototype.constructor = LinksDirectory;

LinksDirectory.prototype.treat = function(response){
	ret = [];
	i = 0;
	j = 0;
    while(info[i]) {
        j = 0;
        while(info[i].entities.urls[j]) {
            ret.push({"link" : info[i].entities.urls[j].url});
            j ++;
        }
        i ++;
    }
    response.end(JSON.stringify(ret));
}

LinksDirectory.prototype.respondToRequest = function(response){
    Root.prototype.respondToRequest.call(this, response);
}


//Creating TweetDirectory class.
//This class will treat requests for "/tweet"
//Inherits from Root
function TweetDirectory(pathString){
    Root.call(this, pathString);
    this.level = 1;
}

TweetDirectory.prototype.setSubDirectories = function(){}
TweetDirectory.prototype = new Root();
TweetDirectory.prototype.constructor = TweetDirectory;

TweetDirectory.prototype.treat = function(response){
	ret = [];
    id = param.id;
	i = 0;
    while(info[i]) {
        if (info[i].id == id) {
            ret = info[i];
            response.end(JSON.stringify(ret));
        }
        i ++;
    }
    ret = {};
    response.end(JSON.stringify(ret));
}

TweetDirectory.prototype.respondToRequest = function(response){
    Root.prototype.respondToRequest.call(this, response);
}

//Creating UserDirectory class.
//This class will treat requests for "/user"
//Inherits from Root
function UserDirectory(pathString){
    Root.call(this, pathString);
    this.level = 1;
}

UserDirectory.prototype.setSubDirectories = function(){}
UserDirectory.prototype = new Root();
UserDirectory.prototype.constructor = UserDirectory;

UserDirectory.prototype.treat = function(response){
	ret = [];
    id = param["id"];
	i = 0;
    while(info[i]) {
        if (info[i].user.id == id) {
            ret = info[i].user;
            response.end(JSON.stringify(ret));
        }
        i ++;
    }
    ret = {};
    response.end(JSON.stringify(ret));
}

UserDirectory.prototype.respondToRequest = function(response){
    Root.prototype.respondToRequest.call(this, response);
}

//Creating MostPopularsDirectory class.
//This class will treat requests for "/tweet"
//Inherits from Root
function MostPopularsDirectory(pathString){
    Root.call(this, pathString);
    this.level = 1;
}

MostPopularsDirectory.prototype.setSubDirectories = function(){}
MostPopularsDirectory.prototype = new Root();
MostPopularsDirectory.prototype.constructor = MostPopularsDirectory;

MostPopularsDirectory.prototype.treat = function(response){
	ret = [];
	i = 0;
    while(info[i]) {
        if (info[i].user.followers_count > 1000000) {
            ret.push(info[i].user);
        }
        i ++;
    }
    response.end(JSON.stringify(ret));
}

MostPopularsDirectory.prototype.respondToRequest = function(response){
    Root.prototype.respondToRequest.call(this, response);
}

// Reading the json file
fs.readFile(file, 'utf8', function(err, data) {
    if (err) {
        console.log("" + err);
        return;
    }
    try {
        info = JSON.parse(data);
    } catch (e) {
        console.log('Error: ' + e);
        return;
    }
});

// Creates a HTTP server.
http.createServer(function(request, response) {  

    // Getting the path
    var pathname = url.parse(request.url).pathname;
    // Getting the parameters, if there are any
    param = querystring.parse(request.url.replace(pathname + "?", ""));
    response.writeHead(200, {'Content-Type': 'application/json'});
    var splitPath = pathname.split("/");
    if (request.method == 'GET') {
        var requestHandler = new Root(splitPath);		
        requestHandler.respondToRequest(response);
    }
}).listen(PORT); // Server starts to listen on port 4321.

// Writes info on Node's console. 
console.log('Server running at http://127.0.0.1:' + PORT + '/');
